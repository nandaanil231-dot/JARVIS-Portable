J.A.R.V.I.S PORTABLE — ULTIMATE FUSION UI BUILD

START
1. Extract this ZIP.
2. Copy the JARVIS_PORTABLE_ULTIMATE folder to your microSD card.
3. Open JARVIS.html in a modern browser.

INCLUDED
- Animated Arc Reactor-inspired HUD.
- Responsive Android/Windows browser layout.
- Listening/processing/speaking visual states.
- Browser speech input where supported and British-English speech output.
- Local note memory in browser storage.
- Permission Centre for microphone, camera, location and notifications.
- Device time, display dimensions, network status and battery where supported.

LIMITATIONS
This is a front-end prototype, not a completed AI assistant. It does not yet
include connected cloud AI, offline language models, a Windows EXE, Android APK,
background wake word, privileged system access or full OS automation.
Permissions are requested only after the user selects the relevant feature.
Opening a local HTML file may restrict browser microphone/camera/location APIs.
Browser memory is not guaranteed to be stored on the microSD card. Do not store
sensitive information in this demo. Android cannot execute Windows EXE files.
